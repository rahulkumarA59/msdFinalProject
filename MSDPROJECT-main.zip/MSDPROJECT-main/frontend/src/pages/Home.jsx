import React from "react";

const Home = () => (
  <div className="home">
    <h1>Welcome to Manager Contact System</h1>
    <p>Manage all your company managers easily from one place.</p>
  </div>
);

export default Home;
